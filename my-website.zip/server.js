// required প্যাকেজগুলো ইমপোর্ট করা
const express = require('express');
const path = require('path');
require('dotenv').config(); // .env ফাইল থেকে ডাটা নেওয়ার জন্য

const app = express();
const PORT = process.env.PORT || 3000;

// ১. স্ট্যাটিক ফাইল সার্ভ করা (public ফোল্ডারের ভেতরের সব ফাইল ব্রাউজারে দেখাবে)
app.use(express.static(path.join(__dirname, 'public')));

// ২. ডাটা পার্স করার জন্য মিডলওয়্যার (ফর্ম থেকে আসা ডাটা রিসিভ করতে)
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ৩. একটি কাস্টম API তৈরি করা (যা পরে React বা JS দিয়ে ফেচ করা যাবে)
app.get('/api/status', (req, res) => {
    res.json({
        status: "success",
        message: "Backend is running perfectly!",
        time: new Date().toISOString()
    });
});

// ৪. কন্টাক্ট ফর্মের ডাটা রিসিভ করার API (উদাহরণ)
app.post('/api/contact', (req, res) => {
    const { name, email, message } = req.body;
    
    // এখানে আমরা চাইলে ডাটাবেসে ডাটা সেভ করতে পারি। আপাতত কনসোলে দেখাবো।
    console.log(`নতুন মেসেজ এসেছে - নাম: ${name}, ইমেইল: ${email}`);
    
    res.json({
        success: true,
        message: "Thank you! Your message has been received."
    });
});

// ৫. সার্ভার চালু করা
app.listen(PORT, () => {
    console.log(`=========================================`);
    console.log(`🚀 ULTRA PRO SERVER IS RUNNING!`);
    console.log(`🌐 Local URL: http://localhost:${PORT}`);
    console.log(`=========================================`);
});