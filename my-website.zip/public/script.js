// 1. Lenis Smooth Scroll
const lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smooth: true,
});
function raf(time) {
    lenis.raf(time);
    requestAnimationFrame(raf);
}
requestAnimationFrame(raf);

// 2. Audio Engine
const AudioContext = window.AudioContext || window.webkitAudioContext;
let audioCtx;
let soundEnabled = true;
function playSound(type) {
    if (!soundEnabled) return;
    if (!audioCtx) audioCtx = new AudioContext();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain); gain.connect(audioCtx.destination);
    const now = audioCtx.currentTime;
    if (type === 'hover') {
        osc.type = 'sine'; osc.frequency.setValueAtTime(600, now); osc.frequency.exponentialRampToValueAtTime(900, now + 0.1);
        gain.gain.setValueAtTime(0.02, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
        osc.start(now); osc.stop(now + 0.1);
    } else if (type === 'click') {
        osc.type = 'triangle'; osc.frequency.setValueAtTime(400, now); osc.frequency.exponentialRampToValueAtTime(200, now + 0.2);
        gain.gain.setValueAtTime(0.05, now); gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
        osc.start(now); osc.stop(now + 0.2);
    }
}
document.getElementById('soundToggle').addEventListener('click', (e) => {
    e.stopPropagation(); soundEnabled = !soundEnabled;
    e.target.textContent = soundEnabled ? '🔊' : '🔇'; playSound('click');
});
document.querySelectorAll('[data-sound]').forEach(el => {
    el.addEventListener('mouseenter', () => playSound('hover'));
    el.addEventListener('click', () => playSound('click'));
});

// 3. Custom Cursor & Magnetic Buttons
const dot = document.querySelector('.cursor-dot');
const ring = document.querySelector('.cursor-ring');
let mouseX = 0, mouseY = 0, ringX = 0, ringY = 0;
window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX; mouseY = e.clientY;
    dot.style.left = `${mouseX}px`; dot.style.top = `${mouseY}px`;
});
function animateCursor() {
    ringX += (mouseX - ringX) * 0.15; ringY += (mouseY - ringY) * 0.15;
    ring.style.left = `${ringX}px`; ring.style.top = `${ringY}px`;
    requestAnimationFrame(animateCursor);
}
animateCursor();
const magnetics = document.querySelectorAll('.magnetic');
magnetics.forEach(el => {
    el.addEventListener('mousemove', (e) => {
        const rect = el.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        gsap.to(el, { x: x * 0.4, y: y * 0.4, duration: 0.3 });
    });
    el.addEventListener('mouseleave', () => gsap.to(el, { x: 0, y: 0, duration: 0.3 }));
    el.addEventListener('mouseenter', () => ring.classList.add('cursor-hover'));
    el.addEventListener('mouseleave', () => ring.classList.remove('cursor-hover'));
});

// 4. Three.js 3D Distorted Sphere
const canvas = document.getElementById('webgl-canvas');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
const geometry = new THREE.IcosahedronGeometry(2, 15); 
const material = new THREE.MeshNormalMaterial({ wireframe: true, transparent: true, opacity: 0.1 });
const sphere = new THREE.Mesh(geometry, material);
scene.add(sphere); camera.position.z = 5;
let targetX = 0, targetY = 0;
window.addEventListener('mousemove', (e) => {
    targetX = (e.clientX / window.innerWidth) * 2 - 1;
    targetY = -(e.clientY / window.innerHeight) * 2 + 1;
});
const clock = new THREE.Clock();
function animate3D() {
    const time = clock.getElapsedTime();
    const positions = geometry.attributes.position;
    for (let i = 0; i < positions.count; i++) {
        const x = positions.getX(i), y = positions.getY(i), z = positions.getZ(i);
        const noise = Math.sin(x * 3 + time) * Math.cos(y * 3 + time) * Math.sin(z * 3 + time) * 0.2;
        positions.setXYZ(i, x + x * noise, y + y * noise, z + z * noise);
    }
    positions.needsUpdate = true;
    sphere.rotation.y = time * 0.2;
    camera.position.x += (targetX * 0.5 - camera.position.x) * 0.05;
    camera.position.y += (targetY * 0.5 - camera.position.y) * 0.05;
    camera.lookAt(scene.position);
    renderer.render(scene, camera);
    requestAnimationFrame(animate3D);
}
animate3D();

// 5. Preloader
window.addEventListener('load', () => {
    gsap.to('.preloader-progress', { width: '100%', duration: 1.5, ease: 'power2.inOut' });
    gsap.to('.preloader', { y: '-100%', duration: 1, delay: 1.6, ease: 'power4.inOut', onComplete: () => { document.querySelector('.preloader').style.display = 'none'; } });
});

// 6. Fetch JSON Data & Build Cards
fetch('data.json')
    .then(res => res.json())
    .then(data => {
        const container = document.querySelector('.horizontal-container');
        
        data.services.forEach(service => {
            // Create Card
            const card = document.createElement('div');
            card.className = 'interactive-card';
            card.setAttribute('data-sound', 'click');
            card.innerHTML = `
                <div class="card-bg" style="background: radial-gradient(circle at center, ${service.color}40, transparent 70%);"></div>
                <span class="card-number">0${service.id}</span>
                <h3>${service.title}</h3>
                <p>${service.desc}</p>
            `;
            container.appendChild(card);

            // 3D Tilt & Glow Effect for Newly Created Cards
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                
                gsap.to(card, {
                    rotationX: (y - centerY) / 20,
                    rotationY: (centerX - x) / 20,
                    transformPerspective: 1000,
                    scale: 1.02,
                    duration: 0.5
                });
                
                const bg = card.querySelector('.card-bg');
                bg.style.opacity = '1';
                bg.style.background = `radial-gradient(circle at ${x}px ${y}px, ${service.color}60, transparent 70%)`;
            });

            card.addEventListener('mouseleave', () => {
                gsap.to(card, { rotationX: 0, rotationY: 0, scale: 1, duration: 0.5 });
                card.querySelector('.card-bg').style.opacity = '0';
            });
            
            // Sound on hover
            card.addEventListener('mouseenter', () => playSound('hover'));
        });

        // Initialize Horizontal Scroll AFTER cards are created
        initHorizontalScroll();
    })
    .catch(err => console.error("JSON Load Error:", err));

// 7. GSAP Horizontal Scroll (Runs after JSON loads)
function initHorizontalScroll() {
    const horizontalSection = document.querySelector('.horizontal-section');
    const container = document.querySelector('.horizontal-container');

    gsap.to(container, {
        x: () => -(container.scrollWidth - window.innerWidth),
        ease: 'none',
        scrollTrigger: {
            trigger: horizontalSection,
            pin: true,
            scrub: 1,
            start: 'top top',
            end: () => '+=' + (container.scrollWidth - window.innerWidth),
            invalidateOnRefresh: true
        }
    });

    // About Section Text Reveal
    gsap.from('.reveal-text', {
        scrollTrigger: { trigger: '.about-section', start: 'top 80%' },
        y: 100, opacity: 0, duration: 1.5, ease: 'power4.out'
    });
}